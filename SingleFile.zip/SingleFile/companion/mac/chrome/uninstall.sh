#!/bin/sh
rm -f ~/Library/Application Support/Google/Chrome/NativeMessagingHosts/singlefile_companion.json
