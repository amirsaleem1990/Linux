#!/bin/sh
rm -f ~/.config/google-chrome/NativeMessagingHosts/singlefile_companion.json