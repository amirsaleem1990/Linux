#ifndef __BCONSOLE_H
#define __BCONOSLE_H

#include "bjoining.h"

#include "bconsole_ligature.h"
#include "bconsole_log2con.h"

#endif
