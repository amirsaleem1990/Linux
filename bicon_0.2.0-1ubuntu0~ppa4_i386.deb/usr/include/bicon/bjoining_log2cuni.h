#ifndef __BJOINING_LOG2CUNI_H
#define __BJOINING_LOG2CUNI_H

#include "bjoining.h"

int bjoining_log2cuni (
  unichar *str,
  int len,
  unichar *cstr,
  int *clen,
  int options);

#endif
