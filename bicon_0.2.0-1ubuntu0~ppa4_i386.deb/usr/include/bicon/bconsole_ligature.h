#ifndef __BCONSOLE_LIGATURE_H
#define __BCONSOLE_LIGATURE_H

#include "bconsole.h"

int bconsole_ligature (
  unichar *us,
  int *len,
  int options);

#endif
